module.exports = {
	test: /\.vue$/,
	loader: 'vue-loader',
};
