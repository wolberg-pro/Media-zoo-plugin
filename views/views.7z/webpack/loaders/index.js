const loaders = [require('./vue'), require('./babel'), require('./postcss'), require('./files'), require('./fonts')];

module.exports = loaders;
