// For global getters
export default () => {};
