<template>
  <footer class="site-footer bg-teal-500 text-white flex items-center justify-between flex-wrap bg-teal-500 px-6 py-3">
		Build By
		<el-link type="primary" disabled>Wolberg Pro@2020</el-link>
  </footer>
</template>

<style type="postcss" scoped></style>
3
